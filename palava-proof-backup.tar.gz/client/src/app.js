// SUPER SIMPLE VERSION - Define functions directly
console.log('🔥 app.js loaded successfully!');

// Define functions in global scope
function markAccurate() {
    alert('Thank you for your feedback! This helps improve Palava Proof.');
    return false;
}

function markInaccurate() {
    alert('Thank you for letting us know. We\'ll review this message.');
    return false;
}

function shareResult() {
    // Get just the message from the input field, nothing else
    const messageInput = document.getElementById('messageInput');
    const message = messageInput ? messageInput.value.trim() : '';
    
    if (!message) {
        alert('No message to share. Please check a message first.');
        return;
    }
    
    // Create a clean share text
    const shareText = `⚠️ Palava Proof Scam Alert ⚠️\n\nSuspicious message: "${message}"\n\nCheck scams at Palava Proof - Liberia's Community Scam Shield`;
    
    if (navigator.share) {
        navigator.share({
            title: 'Palava Proof Scam Alert',
            text: shareText,
            url: window.location.href,
        }).catch((error) => {
            console.log('Share cancelled or failed:', error);
            copyToClipboard(shareText);
        });
    } else {
        copyToClipboard(shareText);
    }
    return false;
}

// Helper function for copying to clipboard
function copyToClipboard(text) {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    document.body.appendChild(textarea);
    textarea.select();
    textarea.setSelectionRange(0, 99999); // For mobile devices
    
    try {
        document.execCommand('copy');
        alert('📋 Warning copied to clipboard! You can now paste and share it with friends.');
    } catch (err) {
        alert('Could not copy. Please share this message manually:\n\n' + text);
    }
    
    document.body.removeChild(textarea);
}

// Explicitly attach to window
window.markAccurate = markAccurate;
window.markInaccurate = markInaccurate;
window.shareResult = shareResult;

// Test if functions work
console.log('✅ Functions available:', {
    markAccurate: typeof markAccurate,
    markInaccurate: typeof markInaccurate,
    shareResult: typeof shareResult
});

// Main app code
document.addEventListener('DOMContentLoaded', () => {
    console.log('📱 DOM ready');
    
    // Set up check button
    const checkBtn = document.getElementById('checkButton');
    const messageInput = document.getElementById('messageInput');
    const resultBox = document.getElementById('result');
    const reportBtn = document.getElementById('reportButton');
    
    if (checkBtn) {
        checkBtn.addEventListener('click', function() {
            const message = messageInput.value.trim();
            
            if (!message) {
                alert('Please enter a message to check');
                return;
            }
            
            resultBox.classList.remove('hidden');
            
            // Simple scam check
            const messageLower = message.toLowerCase();
            const scamIndicators = [
                'won', 'prize', 'free', 'claim', 'click', 'verify', 
                'urgent', 'account', 'bit.ly', 'tinyurl', 'orange money',
                'update', 'locked', 'limited', 'congratulations'
            ];
            
            let foundScams = [];
            let confidence = 0;
            
            scamIndicators.forEach(word => {
                if (messageLower.includes(word)) {
                    confidence += 10;
                    foundScams.push(word);
                }
            });
            
            // Check for shortened URLs
            if (message.includes('bit.ly') || message.includes('tinyurl') || message.includes('goo.gl')) {
                confidence += 20;
            }
            
            // Check for Liberian phone numbers
            if (message.match(/(0\d{9}|\+231\d{9}|077|088)/)) {
                confidence += 15;
            }
            
            confidence = Math.min(confidence, 100);
            const isScam = confidence > 30;
            
            // Build warnings HTML
            let warningsHtml = '';
            if (foundScams.length > 0) {
                warningsHtml = '<div class="warnings"><h4>⚠️ Warning Signs Found:</h4><ul>';
                foundScams.forEach(word => {
                    warningsHtml += `<li>Suspicious word: "${word}"</li>`;
                });
                warningsHtml += '</ul></div>';
            }
            
            if (message.includes('bit.ly') || message.includes('tinyurl')) {
                warningsHtml += '<div class="warnings"><p>⚠️ Shortened URLs can hide dangerous websites</p></div>';
            }
            
            // Display result
            resultBox.innerHTML = `
                <div class="result-header ${isScam ? 'scam' : 'safe'}">
                    <span class="status-emoji">${isScam ? '⚠️' : '✅'}</span>
                    <span class="status-text">${isScam ? '⚠️ PALAVA DETECTED! Be careful!' : 'This message appears safe'}</span>
                    <span class="confidence">${confidence}% confidence</span>
                </div>
                ${warningsHtml}
                <div class="result-actions">
                    <p>Was this helpful?</p>
                    <button onclick="markAccurate()">✅ Yes, accurate</button>
                    <button onclick="markInaccurate()">❌ No, needs review</button>
                </div>
                <div class="share">
                    <button onclick="shareResult()">📢 Share this warning</button>
                </div>
            `;
            
            // Scroll to result
            resultBox.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        });
    }
    
    // Report button
    if (reportBtn) {
        reportBtn.addEventListener('click', () => {
            const message = messageInput.value.trim();
            if (message) {
                alert(`📢 Thank you for reporting!\n\nWe'll investigate this message: "${message.substring(0, 50)}..."`);
            } else {
                alert('Please paste the scam message in the box above before reporting.');
            }
        });
    }
    
    // Allow Ctrl+Enter to check
    if (messageInput) {
        messageInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && e.ctrlKey) {
                checkBtn.click();
            }
        });
    }
});

// Service Worker
if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/sw.js')
        .then(() => console.log('✅ Service Worker registered'))
        .catch(err => console.log('❌ Service Worker error:', err));
}
