#!/bin/bash
cd ~/palava-proof/backend
source venv/bin/activate
cd app
python3 app.py
